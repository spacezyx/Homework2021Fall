# 朴素贝叶斯
# 519021910547 曾宇欣

from timeit import default_timer as timer

import pandas as pd
import numpy as np
from sklearn.naive_bayes import BernoulliNB
from sklearn.naive_bayes import GaussianNB, MultinomialNB
import matplotlib.pyplot as plt

x_train_file = 'src/data/X_train.csv'
y_train_file = 'src/data/Y_train.csv'
x_test_file = 'src/data/X_test.csv'
y_test_file = 'src/data/Y_test.csv'

xtrain = pd.read_csv(x_train_file)
ytrain = pd.read_csv(y_train_file)
xtest = pd.read_csv(x_test_file)
ytest = pd.read_csv(y_test_file)

x_train = np.array(xtrain)
y_train = np.array(ytrain)
x_test = np.array(xtest)
y_test = np.array(ytest)


# 确认读到的内容是否正确
def get_data():
    print((len(x_train)))
    print((len(y_train)))
    print((len(x_test)))
    print((len(y_test)))
    print(x_train)
    print(y_train)
    print(x_test)
    print(y_test)


# 高斯朴素贝叶斯
def gauss_bayes():
    gnb = GaussianNB().fit(x_train, y_train.ravel())
    acc_score = gnb.score(x_test, y_test)
    train_score = gnb.score(x_train, y_train)
    print("高斯朴素贝叶斯分类器的训练集准确度为", train_score)
    return acc_score, train_score


# 多项式朴素贝叶斯
def multi_bayes():
    mnb = MultinomialNB().fit(x_train, y_train.ravel())
    acc_score = mnb.score(x_test, y_test)
    train_score = mnb.score(x_train, y_train)
    print("多项式朴素贝叶斯分类器的训练集准确度为", train_score)
    return acc_score, train_score


# 伯努利朴素贝叶斯
def bernoulli_bayes():
    bnl = BernoulliNB().fit(x_train, y_train.ravel())
    acc_score = bnl.score(x_test, y_test)
    train_score = bnl.score(x_train, y_train)
    print("伯努利朴素贝叶斯分类器的训练集准确度为", train_score)
    return acc_score, train_score


if __name__ == '__main__':
    # get_data()
    gauss_tic = timer()
    gauss_score, gs = gauss_bayes()
    gauss_toc = timer()
    gauss_time = gauss_toc - gauss_tic
    print("高斯朴素贝叶斯分类器的测试集准确度为%f, 所用时间为%f秒" % (gauss_score, gauss_time))
    multi_tic = timer()
    multi_score, ms = multi_bayes()
    multi_toc = timer()
    multi_time = multi_toc - multi_tic
    print("多项式朴素贝叶斯分类器的测试集准确度为%f, 所用时间为%f秒" % (multi_score, multi_time))
    bernoulli_tic = timer()
    bernoulli_score, bs = bernoulli_bayes()
    bernoulli_toc = timer()
    bernoulli_time = bernoulli_toc - bernoulli_tic
    print("伯努利朴素贝叶斯分类器的测试集准确度为%f, 所用时间为%f秒" % (bernoulli_score, bernoulli_time))

    # 这两行代码解决 plt 中文显示的问题
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    # 输入统计数据
    types = ('高斯朴素贝叶斯分类器', '多项式朴素贝叶斯分类器', '伯努利朴素贝叶斯分类器')
    trainsscore = [gauss_score, multi_score, bernoulli_score]
    testscore = [gs, ms, bs]

    bar_width = 0.3  # 条形宽度
    index_train = np.arange(len(types))
    index_test = index_train + bar_width

    # 使用两次 bar 函数画出两组条形图
    plt.bar(index_train, height=trainsscore, width=bar_width, color='b', label='训练集')
    plt.bar(index_test, height=testscore, width=bar_width, color='g', label='测试集')

    # 显示数据标签
    for a, b in zip(index_train, trainsscore):
        plt.text(a, b,
                 b,
                 ha='center',
                 va='bottom',
                 fontsize=8
                 )

    for a, b in zip(index_test, testscore):
        plt.text(a, b,
                 b,
                 ha='center',
                 va='bottom',
                 fontsize=8
                 )

    plt.legend()  # 显示图例
    plt.xticks(index_train + bar_width / 2, types)
    plt.ylabel('准确度')  # 纵坐标轴标题
    plt.title('朴素贝叶斯分类器')  # 图形标题

    plt.show()
