# 逻辑回归
# 519021910547 曾宇欣

from timeit import default_timer as timer

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn import preprocessing


# sigmoid函数
def sigmoid(z):
    return 1 / (1 + np.exp(-z))


# 梯度下降
def BGD(dataSet, eps, max):
    cols = dataSet.shape[1]
    xMat = dataSet[:, 0:cols - 1]
    yMat = dataSet[:, cols - 1:]

    m, n = xMat.shape
    bound = 0.0000001
    weights = np.zeros((n, 1))
    tmpr = [acc_rate(dataSet, weights)]
    costs = [cost(xMat, yMat, weights)]  # 损失值
    for k in range(max):
        h = sigmoid(np.dot(xMat, weights))
        error = (yMat - h)
        weights = weights + eps * np.dot(xMat.T, error)
        # 为方便测量训练时长，注释了计算每一次迭代的loss和accuracy内容
        # newcost = cost(xMat, yMat, weights)
        # costs.append(newcost)
        # tmpr.append(acc_rate(dataSet, weights))
        if np.linalg.norm(np.dot(xMat.T, error)) < bound:
            break
    return weights, costs, tmpr


def logistic(dataSet, eps, max):
    ws, costs, tmpr = BGD(dataSet, eps, max)
    # 方便测量时长，将折线图绘制部分进行注释，如需运行去除注释即可
    # fig, ax = plt.subplots(figsize=(12, 4))
    # ax.plot(np.arange(len(costs)), costs, 'r')
    # ax.set_xlabel('times')
    # ax.set_ylabel('Cost')
    # ax.set_title('cost of alpha = %f, cycles = %f' % (eps, max))
    # plt.show()
    #
    # figt, bx = plt.subplots(figsize=(12, 4))
    # bx.plot(np.arange(len(tmpr)), tmpr, 'b')
    # bx.set_xlabel('times')
    # bx.set_ylabel('accuracy')
    # bx.set_title('accuracy of alpha = %f, cycles = %f' % (eps, max))
    # plt.show()
    return ws


# 输入X和θ得到预测值
def model(X, weight):
    return sigmoid(np.dot(X, weight.T))


# 计算损失函数
def cost(X, y, weight):
    left = np.multiply(-y, np.log(model(X, weight.T)))
    right = np.multiply(1 - y, np.log(1 - model(X, weight.T)))
    return np.sum(left - right) / len(X)


# 计算准确率
def acc_rate(dataSet, weight):
    cols = dataSet.shape[1]
    X = dataSet[:, 0:cols - 1]
    y = dataSet[:, cols - 1:]
    p = model(X, weight.T)
    pt = p.flatten()
    for i, j in enumerate(pt):
        if j < 0.5:
            pt[i] = 0
        else:
            pt[i] = 1

    ylabel = y.flatten()
    t_score = (ylabel == pt).mean()
    return t_score


if __name__ == '__main__':
    x_train_file = 'src/data/X_train.csv'
    y_train_file = 'src/data/Y_train.csv'
    x_test_file = 'src/data/X_test.csv'
    y_test_file = 'src/data/Y_test.csv'

    xtrain = pd.read_csv(x_train_file)
    ytrain = pd.read_csv(y_train_file)
    xtest = pd.read_csv(x_test_file)
    ytest = pd.read_csv(y_test_file)

    xtrain = pd.DataFrame(preprocessing.normalize(xtrain, norm='max', axis=0), columns=xtrain.columns)
    xtest = pd.DataFrame(preprocessing.normalize(xtest, norm='max', axis=0), columns=xtest.columns)

    # 进行数据拼接
    pdData = pd.concat([xtrain, ytrain], axis=1)
    ptData = pd.concat([xtest, ytest], axis=1)

    logistic_tic1 = timer()
    ws = logistic(pdData.values, 0.0001, 15000)
    logistic_toc1 = timer()
    logistic_time1 = logistic_toc1 - logistic_tic1
    score1 = acc_rate(pdData.values, ws)
    score2 = acc_rate(ptData.values, ws)

    print("逻辑回归的测试集准确率是 %5f,所用时间是%d" % (score1, logistic_time1))
    print("逻辑回归的测试集准确率是 %f" % score2)

    logistic_tic2 = timer()
    ws = logistic(pdData.values, 0.005, 15000)
    logistic_toc2 = timer()
    logistic_time2 = logistic_toc2 - logistic_tic2
    score12 = acc_rate(pdData.values, ws)
    score22 = acc_rate(ptData.values, ws)

    logistic_tic3 = timer()
    ws = logistic(pdData.values, 0.0001, 1500)
    logistic_toc3 = timer()
    logistic_time3 = logistic_toc3 - logistic_tic3
    score13 = acc_rate(pdData.values, ws)
    score23 = acc_rate(ptData.values, ws)

    logistic_tic4 = timer()
    ws = logistic(pdData.values, 0.005, 1500)
    logistic_toc4 = timer()
    logistic_time4 = logistic_toc4 - logistic_tic4
    score14 = acc_rate(pdData.values, ws)
    score24 = acc_rate(ptData.values, ws)

    # 这两行代码解决 plt 中文显示的问题
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False

    # 输入统计数据
    types = (
        '学习率 = 0.0001，迭代次数 = 15000', '学习率 =  0.005，迭代次数 = 15000', '学习率 =  0.0001，迭代次数 = 1500',
        '学习率 =  0.005，迭代次数 = 1500')
    trainsscore = [score1, score12, score13, score14]
    testscore = [score2, score22, score23, score24]

    bar_width = 0.3  # 条形宽度
    index_train = np.arange(len(types))
    index_test = index_train + bar_width

    # 使用两次 bar 函数画出两组条形图
    plt.bar(index_train, height=trainsscore, width=bar_width, color='b', label='训练集')
    plt.bar(index_test, height=testscore, width=bar_width, color='g', label='测试集')

    # 显示数据标签
    for a, b in zip(index_train, trainsscore):
        plt.text(a, b,
                 b,
                 ha='center',
                 va='bottom',
                 fontsize=8
                 )

    for a, b in zip(index_test, testscore):
        plt.text(a, b,
                 b,
                 ha='center',
                 va='bottom',
                 fontsize=8
                 )


    plt.legend()  # 显示图例
    plt.xticks(index_train + bar_width / 2, types)
    plt.ylabel('准确度')  # 纵坐标轴标题
    plt.title('逻辑回归')  # 图形标题
    plt.show()

    print(trainsscore)
    print(testscore)
    print(logistic_time1)
    print(logistic_time2)
    print(logistic_time3)
    print(logistic_time4)
